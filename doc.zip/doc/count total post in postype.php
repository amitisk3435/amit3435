<?php $posts = get_posts('post_type=videos&category=4'); 
$count = count($posts); 
echo $count; 
?>
