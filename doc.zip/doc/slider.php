<?php
				$i = 1;
				$arys = array('post_type'=>'slider','order'=>'ASC');
				$query = new wp_query ($arys);
				while( $query->have_posts() ): $query->the_post() ;
				$img = wp_get_attachment_url(get_post_thumbnail_id($result->ID));

      		?>

        <div class="item banner-item <?php if($i == 1) { echo 'active';}?>"  style="background:url(<?php echo $img; ?>); background-size:cover;">
          <div class="carousel-caption textformating">

            <?php the_content(); ?>
            <?php $vdo_url = get_field('video_link');?>

            <p><a href="#" class="video-btn" data-toggle="modal" data-src="<?php echo $vdo_url;?>" data-target="#myModal"><img src="<?php bloginfo('template_url');?>/images/play-button.png"></a></p>

          </div>
        </div>

        <?php $i++; endwhile; ?>
