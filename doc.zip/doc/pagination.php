Pagination code


<?php 
      $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
      $blog_array = array('post_type'=>'blogs','posts_per_page'=>9 , 'paged'=> $paged);
      $blog_query = new wp_query($blog_array);
      while($blog_query->have_posts()): $blog_query->the_post();
      $blog_image = wp_get_attachment_url(get_post_thumbnail_id($blog_query->id));
?>


<nav aria-label="Page navigation example">
<?php
        global $wp_query;
        $current = max( 1, absint( get_query_var( 'paged' ) ) );
        $pagination = paginate_links( array(
          'base' => str_replace( PHP_INT_MAX, '%#%', esc_url( get_pagenum_link( PHP_INT_MAX ) ) ),
          'format' => '?paged=%#%',
          'current' => $current,
          'total' => $blog_query->max_num_pages,          
          'type' => 'array',
          'prev_text' => '&laquo;',
          'next_text' => '&raquo;',
        ) ); ?>
      <?php if ( ! empty( $pagination ) ) : ?>
        <ul class="pagination">
          <?php foreach ( $pagination as $key => $page_link ) : ?>
            <li class="paginated_link<?php if ( strpos( $page_link, 'current' ) !== false ) { echo ' active'; } ?>"><?php echo $page_link ?></li>
          <?php endforeach ?>
        </ul>
      <?php endif ?>
 </nav>
 

change blog_quey in second line according to post type

