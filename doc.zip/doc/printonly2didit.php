<script type="text/javascript">
    $('.twodigit').keyup(function(){
       var num= $('.twodigit').val().length;
       // console.log(num);
       if(num>2){
        $('.twodigit').val('');
       }
    });
</script>
