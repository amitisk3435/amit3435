<?php  if( have_rows('tvastar_post') ): 
  while( have_rows('tvastar_post') ): the_row(); ?>

    <div class="col-xs-12 col-sm-6">
    <div class="project_img">
   <figure>
   <img src="<?php the_sub_field('image'); ?>" alt="Some awesome text"/></figure>
 </div>
    <?php the_sub_field('url'); ?>  
    </div>
<?php endwhile; endif; ?>