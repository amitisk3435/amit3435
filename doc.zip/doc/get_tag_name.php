For Geting A tag name-

<?php $post_tags = get_the_tags($post->id);
  
   if ( $post_tags ) {
    foreach( $post_tags as $tag ) { ?>
    <a href="<?php echo esc_url( get_tag_link( $tag->term_id ) ); ?>" title="<?php echo esc_attr( $tag->name ); ?>">
    <?php
    echo $tag->name . ', '; 
 ?>
    </a>
    
   <?php }
}
  ?>
