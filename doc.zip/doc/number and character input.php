Input only number

<script type="text/javascript">$(document).on('keypress','.chknumber',function(event){
    var element=$(this);
    var charpattern = /^[0-9]+$/i ;          
    var field_value=String.fromCharCode(event.which); 

    if(event.which == 0 || event.which == 8 || event.which == 9 || event.which == 39 || charpattern.test(field_value))
    {     
      $(element).css('border','');
      return true;
    }else{
      $(element).css('border','1px solid red');
      return false;
    }

  });</script>

Input only character


  <script type="text/javascript">
   $(function() 
   {
        $('.alpha-only').bind('keyup input',function()
        {       
            if (this.value.match(/[^a-zA-Z áéíóúÁÉÍÓÚüÜ]/g)) 
            {
                this.value = this.value.replace(/[^a-zA-Z áéíóúÁÉÍÓÚüÜ]/g, '');
            }
        });
    });
</script>
